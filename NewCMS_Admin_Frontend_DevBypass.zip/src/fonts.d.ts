declare module '*.ttf';
