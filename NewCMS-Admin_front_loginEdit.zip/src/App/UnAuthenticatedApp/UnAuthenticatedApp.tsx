import React from "react";
import { Redirect, Route, Router, Switch } from "react-router-dom";
import { FullPageLayout } from "../AuthenticatedApp/Layout/FullpageLayout";
import { RegisterContainer } from "../../components/Authentication/RegisterContainer";
import { SigninOidc } from "../../components/Authentication/SigninOidc/SigninOidc";
import { SignOutOidc } from "../../components/Authentication/SignOutOidc/SignOutOidc";
import { ToastTypes } from "../../core/enums";
import { showToast } from "../../core/utils";
import { history } from "./../../history";
import { Login } from "../../screens/Authentication/Login/Login";

const UnAuthenticatedApp: React.FC = () => {
  return (
    <>
      <Router history={history}>
        <Switch>
          <Route
            exact
            path="/Login"
            render={() => (
              <FullPageLayout>
                <Login />
              </FullPageLayout>
            )}
          />

          <Route path="/Register" render={() => <RegisterContainer />} />

          <Route exact path="/" render={() => <Redirect to="/Login" />} />
          <Route path="/signin-oidc" component={SigninOidc} />
          <Route path="/signout-oidc" component={SignOutOidc} />
          <Route
            render={() => {
              history.push("/Login");
              showToast(["لطفا ابتدا وارد شوید"], ToastTypes.error);
              return null;
            }}
          />
        </Switch>
      </Router>
    </>
  );
};

export { UnAuthenticatedApp };
