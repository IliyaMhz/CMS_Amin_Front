import React from "react";
import { Card, CardHeader, CardTitle, Row, Col } from "reactstrap";

const LoginWrapper: React.FC = ({ children }) => {
  return (
    <Row className="m-0 justify-content-center">
      <Col
        sm="10"
        xl="8"
        lg="11"
        md="10"
        className="d-flex justify-content-center"
      >
        <Card className="bg-authentication rounded-0 mb-0 w-100">
          <Row className="m-0">
            <Col lg="7" md="12" className="p-0">
              <Card className="rounded-0 mb-0 p-2">
                <CardHeader className="pb-1 pt-50">
                  <CardTitle>
                    <h4 className="mb-0">ورود به سیستم</h4>
                  </CardTitle>
                </CardHeader>

                {children}
              </Card>
            </Col>
          </Row>
        </Card>
      </Col>
    </Row>
  );
};

export { LoginWrapper };
