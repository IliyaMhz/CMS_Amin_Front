import React, { useState } from "react";
import { Formik, Form } from "formik";
import { Button, Spinner } from "reactstrap";
import * as Yup from "yup";

import { TextInput, PasswordInput } from "../../../common/Form";
import { useUserAuth } from "../../../../core/utils/context/AuthenticationContext";
import { showToast } from "../../../../core/utils";
import { ToastTypes } from "../../../../core/enums";
import { history } from "../../../../history";
import {
  checkMockCredentials,
  buildMockSession,
} from "../../../../core/services/authentication/mock-auth.service";

interface ILoginValues {
  userName: string;
  password: string;
}

const initialValues: ILoginValues = {
  userName: "",
  password: "",
};

const loginValidation = Yup.object({
  userName: Yup.string().required("لطفا نام کاربری خود را وارد کنید"),
  password: Yup.string().required("لطفا رمز عبور خود را وارد کنید"),
});

const LoginForm: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { setTokenState, setUserInfoState, setRoleState } = useUserAuth();

  const onSubmit = (values: ILoginValues) => {
    setIsSubmitting(true);

    if (checkMockCredentials(values.userName, values.password)) {
      const session = buildMockSession();

      setRoleState(session.roles);
      setUserInfoState(session.userInfo);
      setTokenState(session.token);

      showToast(["ورود با موفقیت انجام شد"], ToastTypes.success);
      history.push("/");
    } else {
      showToast(["نام کاربری یا رمز عبور اشتباه است"], ToastTypes.error);
    }

    setIsSubmitting(false);
  };

  return (
    <div className="p-2">
      <Formik
        initialValues={initialValues}
        validationSchema={loginValidation}
        onSubmit={onSubmit}
      >
        <Form>
          <TextInput
            id="userName"
            lableText="نام کاربری"
            name="userName"
            placeholder="نام کاربری"
            significant
            singleSpace={false}
          />

          <PasswordInput
            id="password"
            lableText="رمز عبور"
            name="password"
            placeholder="رمز عبور"
            significant
          />

          <div className="d-flex justify-content-start mt-1">
            <Button
              className="d-flex align-items-center justify-content-center"
              color="primary"
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting && <Spinner color="white" size="sm" />}
              <span className="ml-50">ورود</span>
            </Button>
          </div>
        </Form>
      </Formik>
    </div>
  );
};

export { LoginForm };
