import React from "react";
import { LoginForm } from "../../../components/Authentication/LoginContainer/LoginForm";
import { LoginWrapper } from "../../../components/Authentication/LoginContainer/LoginWrapper";

import "../../../assets/scss/pages/authentication.scss";

const Login: React.FC = () => {
  return (
    <LoginWrapper>
      <LoginForm />
    </LoginWrapper>
  );
};

export { Login };
