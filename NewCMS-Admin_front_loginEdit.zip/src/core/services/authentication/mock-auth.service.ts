import * as storage from "../common/storage/storage.service";

/**
 * Temporary local authentication used only because there is no backend
 * API available yet for the real OIDC login flow. This lets the admin
 * panel be opened and developed against without a working identity
 * server. Remove this file (and its usage in AuthenticationContext and
 * the Login screen) once the real API/OIDC server is ready.
 */

export const MOCK_USERNAME = "Admin";
export const MOCK_PASSWORD = "Admin1405";

// Every role referenced by AuthenticatedRoutesConfig, so the mock admin
// account has access to every page of the panel.
export const MOCK_ROLES: string[] = [
  "UserReal",
  "CmsSetting",
  "UserManagement",
  "Slider",
  "ServiceDesk",
  "QuickAccess",
  "RelatedLink",
  "TextNews",
  "ImageNews",
  "VideoNews",
  "Menu",
];

export interface IMockUserInfo {
  userName: string;
  name: string;
  family: string;
  userInfoId: number;
  authTime: string;
  userType: number;
  roles: string[];
}

export interface IMockSession {
  token: string;
  roles: string[];
  userInfo: IMockUserInfo;
}

const base64UrlEncode = (value: object): string => {
  const json = JSON.stringify(value);
  const base64 = window.btoa(unescape(encodeURIComponent(json)));
  return base64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};

// Builds a JWT-shaped (unsigned) token. The app only ever decodes this
// token locally (jwt-decode), it is never sent to or verified by a real
// server, so it only needs to be well-formed, not cryptographically valid.
const buildMockToken = (): string => {
  const header = { alg: "none", typ: "JWT" };
  const nowInSeconds = Math.floor(Date.now() / 1000);
  const payload = {
    sub: "mock-admin",
    preferred_username: MOCK_USERNAME,
    name: MOCK_USERNAME,
    family_name: "",
    UserType: "1",
    UserInfoId: "1",
    auth_time: nowInSeconds,
    role: MOCK_ROLES,
    iat: nowInSeconds,
    exp: nowInSeconds + 60 * 60 * 24 * 30,
  };
  return `${base64UrlEncode(header)}.${base64UrlEncode(
    payload
  )}.mock-local-signature`;
};

export const checkMockCredentials = (
  userName: string,
  password: string
): boolean => userName === MOCK_USERNAME && password === MOCK_PASSWORD;

// Creates the fake session and persists it to storage so the user stays
// logged in across page refreshes (no backend session/cookie exists).
export const buildMockSession = (): IMockSession => {
  const token = buildMockToken();
  const userInfo: IMockUserInfo = {
    userName: MOCK_USERNAME,
    name: MOCK_USERNAME,
    family: "",
    userInfoId: 1,
    authTime: Date.now().toString(),
    userType: 1,
    roles: MOCK_ROLES,
  };

  storage.setItem("token", token);
  storage.setItem("mockAuth", true);
  storage.setItem("mockUserInfo", userInfo);

  return { token, roles: MOCK_ROLES, userInfo };
};

export const isMockAuthActive = (): boolean =>
  storage.getItem("mockAuth") === "true";

export const getStoredMockUserInfo = (): IMockUserInfo | null => {
  const raw = storage.getItem("mockUserInfo");
  if (!raw) return null;
  try {
    return JSON.parse(raw as string);
  } catch (error) {
    return null;
  }
};

export const clearMockSession = (): void => {
  storage.removeItem("mockAuth");
  storage.removeItem("mockUserInfo");
};
